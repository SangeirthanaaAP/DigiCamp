
  # DigiCamp SaaS UI Design

  This is a code bundle for DigiCamp SaaS UI Design. The original project is available at https://www.figma.com/design/tQnqxMwBsHwJhsW4N4P47O/DigiCamp-SaaS-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  